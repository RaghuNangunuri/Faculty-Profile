<?php
  /**
  * Requires the "PHP Email Form" library
  * The "PHP Email Form" library is available only in the pro version of the template
  * The library should be uploaded to: vendor/php-email-form/php-email-form.php
  * For more info and help: https://bootstrapmade.com/php-email-form/
  */

  // Replace contact@example.com with your real receiving email address
  
  $to = $_POST['remail'];
  $sender_name = $_POST['name'];
  $sender_email = $_POST['email'];
  $subject = $_POST['subject'];
  $message=$_POST['message'];
  
  $headers = "From:" .$sender_name." ".$sender_email;
if(mail($to,$subject,$message,$headers))
echo "Mail sent successfully";
else
echo "Server Error. Please try later."

  
?>
